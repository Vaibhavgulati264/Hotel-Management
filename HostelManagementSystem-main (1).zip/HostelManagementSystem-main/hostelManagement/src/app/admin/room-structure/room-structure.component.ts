import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-room-structure',
  templateUrl: './room-structure.component.html',
  styleUrls: ['./room-structure.component.css']
})
export class RoomStructureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
