import { Component, OnDestroy } from '@angular/core';
// import { Router } from '@angular/router';
// import { Subscription } from 'rxjs';
// import { AuthService } from './auth/auth.service';
// import { User } from './user';

@Component({
  selector: 'hostel-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'hostelManagement';

}
