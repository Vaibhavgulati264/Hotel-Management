export interface User {
    username: string;
    firstName: string;
    lastName: string;
    mobileNumber: string;
    email: string;
    newPassword: string;
    role: string;
}
