export interface Availability {
    boysStandardRooms: number;
    boysDeluxeRooms: number;
    boysSuperDeluxeRooms: number;
    girlsStandardRooms: number;
    girlsDeluxeRooms: number;
    girlsSuperDeluxeRooms: number;
}
